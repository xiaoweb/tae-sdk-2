 <?
                $smarty = new Smarty();

                $smarty->display("templates/admin.tpl");
?>
